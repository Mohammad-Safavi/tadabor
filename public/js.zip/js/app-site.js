function menu_btn() {
    document.getElementById("ul").style.display = "block";
    document.getElementById("body").style.overflow = "hidden";

}
function menu_close(){
    document.getElementById("ul").style.display = "none";
    document.getElementById("body").style.overflow = "scroll";
}
